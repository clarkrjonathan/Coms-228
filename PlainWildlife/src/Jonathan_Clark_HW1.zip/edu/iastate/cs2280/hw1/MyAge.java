package edu.iastate.cs2280.hw1;

/**
 * @author Jonathan Clark
 */
/**
 * 
 * To be implemented by the Animal class. 
 *
 */
public interface MyAge 
{
	int myAge();	// return age of the animal
}
